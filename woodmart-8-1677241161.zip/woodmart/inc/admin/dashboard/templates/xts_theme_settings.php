<?php

XTS\Page::get_instance()->page_content();
